package com.example.filmster.viewmodels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.filmster.models.Movie
import com.example.filmster.network.ApiClient
import kotlinx.coroutines.launch
import java.io.IOException

class MainViewModel : ViewModel() {

    private val apiKey = "a07e22bc18f5cb106bfe4cc1f83ad8ed" // Consider moving this to a safer place
    private val TAG = "MainViewModel"

    private val _movies = MutableLiveData<List<Movie>>()
    val movies: LiveData<List<Movie>> = _movies

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    init {
        fetchMovies()
    }

    fun fetchMovies() {
        viewModelScope.launch {
            try {
                val response = ApiClient.movieApiService.getNowPlayingMovies(apiKey)
                _movies.postValue(response.results)
                _error.postValue(null) // Clear any previous error
                Log.d(TAG, "Movies fetched successfully: ${response.results.size} movies")
            } catch (e: IOException) {
                Log.e(TAG, "IOException fetching movies: ${e.message}", e)
                _error.postValue("Network error: ${e.message}")
            } catch (e: Exception) {
                Log.e(TAG, "Exception fetching movies: ${e.message}", e)
                _error.postValue("Error fetching movies: ${e.message}")
            }
        }
    }
}
