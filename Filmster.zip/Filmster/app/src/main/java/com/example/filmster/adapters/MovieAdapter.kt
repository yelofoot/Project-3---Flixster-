package com.example.filmster.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.filmster.R
import com.example.filmster.models.Movie

class MovieAdapter(private var movies: List<Movie>) : RecyclerView.Adapter<MovieAdapter.MovieViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_movie, parent, false)
        return MovieViewHolder(view)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        val movie = movies[position]
        holder.bind(movie)
    }

    override fun getItemCount(): Int = movies.size

    fun updateData(newMovies: List<Movie>) {
        movies = newMovies
        notifyDataSetChanged() // Or use DiffUtil for better performance
    }

    inner class MovieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val titleTextView: TextView = itemView.findViewById(R.id.movie_title)
        private val overviewTextView: TextView = itemView.findViewById(R.id.movie_overview)
        private val posterImageView: ImageView = itemView.findViewById(R.id.movie_poster)

        fun bind(movie: Movie) {
            titleTextView.text = movie.title
            overviewTextView.text = movie.overview

            val posterBaseUrl = "https://image.tmdb.org/t/p/w500/"
            Glide.with(itemView.context)
                .load(posterBaseUrl + movie.posterPath)
                .placeholder(R.mipmap.ic_launcher) // Optional placeholder
                .error(R.mipmap.ic_launcher) // Optional error image
                .into(posterImageView)
        }
    }
}
