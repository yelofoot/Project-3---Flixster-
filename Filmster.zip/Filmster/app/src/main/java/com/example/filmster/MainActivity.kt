package com.example.filmster

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.filmster.adapters.MovieAdapter
import com.example.filmster.models.Movie
import com.example.filmster.viewmodels.MainViewModel
import com.google.android.material.appbar.MaterialToolbar

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"

    private lateinit var movieRecyclerView: RecyclerView
    private lateinit var movieAdapter: MovieAdapter
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val toolbar: MaterialToolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            // Apply padding to the main content area, not the AppBar
            // The RecyclerView is constrained below the AppBar, so we can apply padding to its parent or adjust margins
            // For simplicity, let's keep padding on the root view but ensure AppBar handles its own insets.
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom) // Set top padding to 0 as AppBar handles it
            // The AppBarLayout with fitsSystemWindows=true should handle the top inset for the toolbar.
            // Adjust the top inset for the RecyclerView if needed, or ensure the main layout's top padding is 0.
            insets
        }

        movieRecyclerView = findViewById(R.id.movie_recycler_view)
        movieAdapter = MovieAdapter(emptyList()) // Start with an empty list
        movieRecyclerView.layoutManager = LinearLayoutManager(this)
        movieRecyclerView.adapter = movieAdapter

        viewModel.movies.observe(this, Observer { movies ->
            movies?.let {
                Log.d(TAG, "Movies LiveData updated: ${it.size} movies")
                movieAdapter.updateData(it)
            }
        })

        viewModel.error.observe(this, Observer { errorMessage ->
            errorMessage?.let {
                Log.e(TAG, "Error LiveData updated: $it")
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
                // Optionally, clear the error from ViewModel after showing it
            }
        })
    }
}
